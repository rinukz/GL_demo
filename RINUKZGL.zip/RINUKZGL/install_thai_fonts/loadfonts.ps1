param(
    [string]$fontDir = (Join-Path $PSScriptRoot "..\fonts")
)

# แปลงเป็น Full Path ให้ชัดเจน
if (Test-Path $fontDir) {
    $fontDir = (Resolve-Path $fontDir).Path
}

Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public class FontHelper {
    [DllImport("user32.dll", SetLastError = true, CharSet = CharSet.Auto)]
    public static extern IntPtr SendMessageTimeout(
        IntPtr hWnd, uint Msg, IntPtr wParam, IntPtr lParam,
        uint fuFlags, uint uTimeout, out IntPtr lpdwResult
    );

    [DllImport("gdi32.dll")]
    public static extern int AddFontResource(string lpFileName);

    public const int HWND_BROADCAST = 0xffff;
    public const uint WM_FONTCHANGE = 0x001D;
    public const uint SMTO_ABORTIFHUNG = 0x0002;
}
"@

if (-not (Test-Path $fontDir)) {
    Write-Error "Folder not found: $fontDir"
    exit 1
}

# 1. โฟลเดอร์ปลายทางระดับ User
$fontsFolder = Join-Path $env:LOCALAPPDATA "Microsoft\Windows\Fonts"
if (-not (Test-Path $fontsFolder)) {
    New-Item -ItemType Directory -Path $fontsFolder -Force | Out-Null
}
$systemFontsFolder = Join-Path $env:windir "Fonts"
$regPath = 'HKCU:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Fonts'

$installedCount = 0

# 2. วนลูปตรวจเช็คทีละฟอนต์
Get-ChildItem -Path $fontDir -File | Where-Object { $_.Extension -match '^\.(ttf|otf)$' } | ForEach-Object {
    $dst = Join-Path $fontsFolder $_.Name
    $sysDst = Join-Path $systemFontsFolder $_.Name

    # ✅ ตรวจสอบก่อนว่ามีฟอนต์นี้อยู่ในเครื่องแล้วหรือไม่ (ทั้ง User และ System)
    if ((Test-Path $dst) -or (Test-Path $sysDst)) {
        Write-Host ("[OK] Already installed: " + $_.Name) -ForegroundColor DarkGray
        return # ข้ามไปตัวถัดไปทันที (ใน ForEach-Object return คือ continue)
    }

    # ถ้ายังไม่มีจริงๆ ค่อย Copy และติดตั้ง
    Write-Host ("Installing: " + $_.Name) -ForegroundColor Cyan
    Copy-Item $_.FullName $dst -Force

    [FontHelper]::AddFontResource($dst) | Out-Null

    $fontType = if ($_.Extension -eq ".otf") { "(OpenType)" } else { "(TrueType)" }
    $fontName = "$([System.IO.Path]::GetFileNameWithoutExtension($_.Name)) $fontType"
    Set-ItemProperty -Path $regPath -Name $fontName -Value $dst

    $installedCount++
}

# 3. ถ้ามีการติดตั้งใหม่ ค่อย Broadcast แจ้ง Windows
if ($installedCount -gt 0) {
    $result = [IntPtr]::Zero
    [FontHelper]::SendMessageTimeout(
        [IntPtr][FontHelper]::HWND_BROADCAST,
        [FontHelper]::WM_FONTCHANGE,
        [IntPtr]::Zero,
        [IntPtr]::Zero,
        [FontHelper]::SMTO_ABORTIFHUNG,
        2000,
        [ref]$result
    ) | Out-Null
    Write-Host "`nSuccessfully installed $installedCount font(s)!" -ForegroundColor Green
} else {
    Write-Host "`nAll fonts are already installed. Nothing to do." -ForegroundColor Green
}