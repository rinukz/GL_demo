@echo off
net session >nul 2>&1 || (powershell start -verb runas '"%~0"' & exit /b)

:: ถอยหลัง 1 ชั้น จาก install_thai_fonts ไปยังโฟลเดอร์ fonts ที่ Root
for %%I in ("%~dp0..\fonts") do set "fontDir=%%~fI"
set "ps1=%~dp0loadfonts.ps1"

echo Installing fonts from: %fontDir%
powershell -NoProfile -ExecutionPolicy Bypass -File "%ps1%" -fontDir "%fontDir%"

echo.
echo --- Finished ---
pause